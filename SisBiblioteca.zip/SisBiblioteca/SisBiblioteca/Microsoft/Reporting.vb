﻿Namespace Microsoft
    Friend Class Reporting
    End Class
End Namespace
