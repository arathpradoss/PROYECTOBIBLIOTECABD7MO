﻿

Partial Class dbbibliotecaData1
End Class

Namespace dbbibliotecaDataSetTableAdapters
    Partial Public Class _TableAdapter
    End Class
End Namespace


Partial Public Class dbbibliotecaDataSetP
End Class
