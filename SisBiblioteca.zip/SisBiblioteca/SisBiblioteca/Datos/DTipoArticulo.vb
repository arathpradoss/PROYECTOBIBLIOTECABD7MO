﻿Imports System.Data.SqlClient
Public Class DTipoArticulo
    Inherits DConexion
    Public Function MostrarGenero() As DataTable
        Try
            Conectar()
            Dim cmd As New SqlCommand("MostrarGenero", con)
            cmd.CommandType = CommandType.StoredProcedure
            Dim tablaTipoArticulo As New DataTable

            If cmd.ExecuteNonQuery Then
                Dim adaptar As New SqlDataAdapter(cmd)
                adaptar.Fill(tablaTipoArticulo)
                Return tablaTipoArticulo
            Else
                Return Nothing
            End If

        Catch ex As Exception
            Return Nothing
            MsgBox(ex.Message)

        Finally
            Desconectar()
        End Try
    End Function


    Public Function AgregarGenero(ByVal lTipoArticulo As LTipoArticulo) As Boolean

        Try
            Conectar()
            Dim cmd As New SqlCommand("AgregarGenero", con)
            cmd.CommandType = CommandType.StoredProcedure

            With cmd.Parameters
                .AddWithValue("@Tipo", lTipoArticulo._Tipo)
            End With

            If cmd.ExecuteNonQuery Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
            Return False

        Finally
            Desconectar()
        End Try
    End Function

    Public Function ModificarGenero(ByVal lTipoArticulo As LTipoArticulo) As Boolean

        Try
            Conectar()
            Dim cmd As New SqlCommand("ModificarGenero", con)
            cmd.CommandType = CommandType.StoredProcedure

            With cmd.Parameters
                .AddWithValue("@CodTipoArticulo", lTipoArticulo._CodTipoArticulo)
                .AddWithValue("@Tipo", lTipoArticulo._Tipo)

            End With

            If cmd.ExecuteNonQuery Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
            Return False

        Finally
            Desconectar()
        End Try
    End Function


    Public Function EliminarGenero(ByVal lTipoArticulo As LTipoArticulo) As Boolean

        Try
            Conectar()
            Dim cmd As New SqlCommand("EliminarGenero", con)
            cmd.CommandType = CommandType.StoredProcedure

            With cmd.Parameters
                .AddWithValue("@CodTipoArticulo", lTipoArticulo._CodTipoArticulo)
            End With

            If cmd.ExecuteNonQuery Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
            Return False

        Finally
            Desconectar()
        End Try
    End Function
End Class
