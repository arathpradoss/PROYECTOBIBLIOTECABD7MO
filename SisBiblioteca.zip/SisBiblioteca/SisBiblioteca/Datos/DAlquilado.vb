﻿Imports System.Data.SqlClient
Public Class DAlquilado
    Inherits DConexion
    Public Function MostrarAlquilado() As DataTable
        Try
            Conectar()
            Dim cmd As New SqlCommand("MostrarAlquilado", con)
            cmd.CommandType = CommandType.StoredProcedure
            Dim tablaalquilado As New DataTable

            If cmd.ExecuteNonQuery Then
                Dim adaptar As New SqlDataAdapter(cmd)
                adaptar.Fill(tablaalquilado)
                Return tablaalquilado
            Else
                Return Nothing
            End If

        Catch ex As Exception
            Return Nothing
            MsgBox(ex.Message)

        Finally
            Desconectar()
        End Try
    End Function
    Public Function MostrarPrestamoCancelado() As DataTable
        Try
            Conectar()
            Dim cmd As New SqlCommand("MostrarAlquilerDevueltos", con)
            cmd.CommandType = CommandType.StoredProcedure
            Dim tablalquilado As New DataTable

            If cmd.ExecuteNonQuery Then
                Dim adaptar As New SqlDataAdapter(cmd)
                adaptar.Fill(tablalquilado)
                Return tablalquilado
            Else
                Return Nothing
            End If

        Catch ex As Exception
            Return Nothing
            MsgBox(ex.Message)

        Finally
            Desconectar()
        End Try
    End Function
    Public Function MostrarAlquilerDeuda(ByVal lprestamo As LAlquilado) As DataTable
        Try
            Conectar()
            Dim cmd As New SqlCommand("MostrarAlquiladoDeudaLecor", con)
            cmd.CommandType = CommandType.StoredProcedure
            Dim tabladeuda As New DataTable


            With cmd.Parameters
                .AddWithValue("@codlector", lprestamo._CodMiembroNuevo)
            End With



            If cmd.ExecuteNonQuery Then
                Dim adaptar As New SqlDataAdapter(cmd)
                adaptar.Fill(tabladeuda)
                Return tabladeuda
            Else
                Return Nothing
            End If

        Catch ex As Exception
            Return Nothing
            MsgBox(ex.Message)

        Finally
            Desconectar()
        End Try
    End Function


    Public Function AgregarAlquilado(ByVal lprestamo As LAlquilado) As Boolean

        Try
            Conectar()
            Dim cmd As New SqlCommand("AgregarPrestamo", con)
            cmd.CommandType = CommandType.StoredProcedure


            With cmd.Parameters
                .AddWithValue("@codlector", lprestamo._CodMiembroNuevo)
                .AddWithValue("@codlibro", lprestamo._CodArticulos)
                .AddWithValue("@fec_devolucion", lprestamo._FecDevolucion)

            End With

            If cmd.ExecuteNonQuery Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
            Return False

        Finally
            Desconectar()
        End Try
    End Function

    Public Function ModificarLibro(ByVal lprestamo As LAlquilado) As Boolean

        Try
            Conectar()
            Dim cmd As New SqlCommand("ModificarPrestamoRetorno", con)
            cmd.CommandType = CommandType.StoredProcedure

            With cmd.Parameters
                .AddWithValue("@codprestamo", lprestamo._CodAlquilado)
            End With

            If cmd.ExecuteNonQuery Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
            Return False

        Finally
            Desconectar()
        End Try
    End Function
End Class