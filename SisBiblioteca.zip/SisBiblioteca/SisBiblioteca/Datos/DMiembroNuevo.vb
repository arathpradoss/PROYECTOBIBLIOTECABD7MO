﻿Imports System.Data.SqlClient
Public Class DMiembroNuevo
    Inherits DConexion


    Public Function MostrarLector() As DataTable
        Try
            Conectar()
            Dim cmd As New SqlCommand("MostrarLectores", con)
            cmd.CommandType = CommandType.StoredProcedure
            Dim tablaMiembroNuevo As New DataTable

            If cmd.ExecuteNonQuery Then
                Dim adaptar As New SqlDataAdapter(cmd)
                adaptar.Fill(tablaMiembroNuevo)
                Return tablaMiembroNuevo
            Else
                Return Nothing
            End If

        Catch ex As Exception
            Return Nothing
            MsgBox(ex.Message)

        Finally
            Desconectar()
        End Try
    End Function
    Public Function VerificarLector(ByVal LMiembro As LMiembroNuevo) As DataTable
        Try
            Conectar()
            Dim cmd As New SqlCommand("VerificarLector", con)
            cmd.CommandType = CommandType.StoredProcedure
            Dim tablaMiembroNuevo As New DataTable

            With cmd.Parameters
                .AddWithValue("@codlector", LMiembro._CodMiembroNuevo)

            End With

            If cmd.ExecuteNonQuery Then
                Dim adaptar As New SqlDataAdapter(cmd)
                adaptar.Fill(tablaMiembroNuevo)
                Return tablaMiembroNuevo
            Else
                Return Nothing
            End If

        Catch ex As Exception
            Return Nothing
            MsgBox(ex.Message)

        Finally
            Desconectar()
        End Try
    End Function


    Public Function AgregarLector(ByVal lMiembro As LMiembroNuevo) As Boolean

        Try
            Conectar()
            Dim cmd As New SqlCommand("AgregarMiembro", con)
            cmd.CommandType = CommandType.StoredProcedure

            With cmd.Parameters
                .AddWithValue("@nombres", lMiembro._Nombres)
                .AddWithValue("@apellidos", lMiembro._Apellidos)
                .AddWithValue("@direccion", lMiembro._Direccion)
                .AddWithValue("@email", lMiembro._Email)
                .AddWithValue("@telefono", lMiembro._Telefono)
            End With

            If cmd.ExecuteNonQuery Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
            Return False

        Finally
            Desconectar()
        End Try
    End Function

    Public Function ModificarLector(ByVal lMiembro As LMiembroNuevo) As Boolean

        Try
            Conectar()
            Dim cmd As New SqlCommand("ModificarLector", con)
            cmd.CommandType = CommandType.StoredProcedure

            With cmd.Parameters
                .AddWithValue("@codlector", lMiembro._CodMiembroNuevo)
                .AddWithValue("@nombres", lMiembro._Nombres)
                .AddWithValue("@apellidos", lMiembro._Apellidos)
                .AddWithValue("@direccion", lMiembro._Direccion)
                .AddWithValue("@email", lMiembro._Email)
                .AddWithValue("@telefono", lMiembro._Telefono)
            End With

            If cmd.ExecuteNonQuery Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
            Return False

        Finally
            Desconectar()
        End Try
    End Function


    Public Function EliminarLector(ByVal lMiembro As LMiembroNuevo) As Boolean

        Try
            Conectar()
            Dim cmd As New SqlCommand("EliminarLector", con)
            cmd.CommandType = CommandType.StoredProcedure

            With cmd.Parameters
                .AddWithValue("@codlector", lMiembro._CodMiembroNuevo)
            End With

            If cmd.ExecuteNonQuery Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
            Return False

        Finally
            Desconectar()
        End Try
    End Function
End Class
