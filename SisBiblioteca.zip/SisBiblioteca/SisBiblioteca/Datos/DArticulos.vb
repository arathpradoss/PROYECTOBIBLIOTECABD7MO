﻿Imports System.Data.SqlClient
Public Class DArticulos
    Inherits DConexion


    Public Function MostrarLibros() As DataTable
        Try
            Conectar()
            Dim cmd As New SqlCommand("MostrarArticulos", con)
            cmd.CommandType = CommandType.StoredProcedure
            Dim tablaarticulos As New DataTable

            If cmd.ExecuteNonQuery Then
                Dim adaptar As New SqlDataAdapter(cmd)
                adaptar.Fill(tablaarticulos)
                Return tablaarticulos
            Else
                Return Nothing
            End If

        Catch ex As Exception
            Return Nothing
            MsgBox(ex.Message)

        Finally
            Desconectar()
        End Try
    End Function
    Public Function VerificarArticulos(ByVal LArticulos As LArticulos) As DataTable
        Try
            Conectar()
            Dim cmd As New SqlCommand("VerificarArticulos", con)
            cmd.CommandType = CommandType.StoredProcedure
            Dim tablaMiembroNuevo As New DataTable

            With cmd.Parameters
                .AddWithValue("@codarticulo", LArticulos._CodArticulos)

            End With

            If cmd.ExecuteNonQuery Then
                Dim adaptar As New SqlDataAdapter(cmd)
                adaptar.Fill(tablaMiembroNuevo)
                Return tablaMiembroNuevo
            Else
                Return Nothing
            End If

        Catch ex As Exception
            Return Nothing
            MsgBox(ex.Message)

        Finally
            Desconectar()
        End Try
    End Function
    Public Function VerificarCantidadLibro(ByVal LArticulos As LArticulos) As DataTable
        Try
            Conectar()
            Dim cmd As New SqlCommand("VerificarCantidadLibro", con)
            cmd.CommandType = CommandType.StoredProcedure
            Dim tablaMiembroNuevo As New DataTable

            With cmd.Parameters
                .AddWithValue("@codarticulo", LArticulos._CodArticulos)

            End With

            If cmd.ExecuteNonQuery Then
                Dim adaptar As New SqlDataAdapter(cmd)
                adaptar.Fill(tablaMiembroNuevo)
                Return tablaMiembroNuevo
            Else
                Return Nothing
            End If

        Catch ex As Exception
            Return Nothing
            MsgBox(ex.Message)

        Finally
            Desconectar()
        End Try
    End Function
    Public Function MostrarStockLibros() As DataTable
        Try
            Conectar()
            Dim cmd As New SqlCommand("MostrarLibrosStock", con)
            cmd.CommandType = CommandType.StoredProcedure
            Dim tablaarticulos As New DataTable

            If cmd.ExecuteNonQuery Then
                Dim adaptar As New SqlDataAdapter(cmd)
                adaptar.Fill(tablaarticulos)
                Return tablaarticulos
            Else
                Return Nothing
            End If

        Catch ex As Exception
            Return Nothing
            MsgBox(ex.Message)

        Finally
            Desconectar()
        End Try
    End Function

    Public Function Agregarlibro(ByVal lArticulos As LArticulos) As Boolean

        Try
            Conectar()
            Dim cmd As New SqlCommand("AgregarLibro", con)
            cmd.CommandType = CommandType.StoredProcedure


            With cmd.Parameters
                .AddWithValue("@titulo", lArticulos._Titulo)
                .AddWithValue("@codautor", lArticulos._CodArticulosAutor)
                .AddWithValue("@codtipoarticulo", lArticulos._CodTipoArticulo)
                .AddWithValue("@codISBN", lArticulos._CodISBN)
                .AddWithValue("@ubicacion", lArticulos._Ubicacion)
                .AddWithValue("@cantidad", lArticulos._Cantidad)
            End With

            If cmd.ExecuteNonQuery Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
            Return False

        Finally
            Desconectar()
        End Try
    End Function

    Public Function ModificarLibro(ByVal lArticulos As LArticulos) As Boolean

        Try
            Conectar()
            Dim cmd As New SqlCommand("ModificarArticulo", con)
            cmd.CommandType = CommandType.StoredProcedure

            With cmd.Parameters
                .AddWithValue("@codarticulo", lArticulos._CodArticulos)
                .AddWithValue("@titulo", lArticulos._Titulo)
                .AddWithValue("@codautor", lArticulos._CodArticulosAutor)
                .AddWithValue("@codtipoarticulo", lArticulos._CodTipoArticulo)
                .AddWithValue("@codISBN", lArticulos._CodISBN)
                .AddWithValue("@ubicacion", lArticulos._Ubicacion)
                .AddWithValue("@cantidad", lArticulos._Cantidad)
            End With

            If cmd.ExecuteNonQuery Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
            Return False

        Finally
            Desconectar()
        End Try
    End Function


    Public Function EliminarLibro(ByVal lArticulos As LArticulos) As Boolean

        Try
            Conectar()
            Dim cmd As New SqlCommand("EliminarLibro", con)
            cmd.CommandType = CommandType.StoredProcedure

            With cmd.Parameters
                .AddWithValue("@codarticulo", lArticulos._CodArticulos)
            End With

            If cmd.ExecuteNonQuery Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
            Return False

        Finally
            Desconectar()
        End Try
    End Function
End Class
