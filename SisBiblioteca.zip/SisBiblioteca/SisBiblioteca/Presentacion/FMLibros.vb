﻿Imports System.Data.SqlClient


Public Class FMLibros
    Dim dconexion As New DConexion

    Dim FuncArticulos As New DArticulos
    Dim DatArticulos As New LArticulos
    Dim FuncArticulosAutor As New DArticulosAutor
    Dim FuncTipoArticulo As New DTipoArticulo
    Dim FuncISBN As New DISBN

    Public CodArticulos As Integer
    Public CodArticulosAutor As Integer
    Public CodTipoArticulo As Integer
    Public CodISBN As Integer
    Private Sub FMArticulos_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call CodArticulos()
        Call CodTipoArticulo()
        Call CodISBN()
    End Sub
    Private Sub btncancelar_Click(sender As Object, e As EventArgs) Handles btncancelar.Click
        Me.Close()
    End Sub

    Private Sub btnAceptar_Click(sender As Object, e As EventArgs) Handles btnAceptar.Click
        Try
            Dim valordecajas As Boolean
            valordecajas = True

            For Each Caja As Control In Me.Controls
                If TypeOf (Caja) Is TextBox Then
                    If Trim(Caja.Text) = "" Then
                        valordecajas = False
                        Exit For
                    End If
                End If
            Next

            If valordecajas Then
                Call ModificarArticulos()
            Else
                MsgBox("Complete Todos los Datos", MsgBoxStyle.Information, "Mensaje del Sistema")
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub


    Public Sub ModificarArticulos()
        Try
            Dim CantidadPrestada As Integer
            Dim CantidadNueva As Integer
            Dim NuevoSotck As Integer
            DatArticulos._CodArticulos = CodArticulos
            DatArticulos._Titulo = txtTitulo.Text
            DatArticulos._CodArticulosAutor = Convert.ToInt32(cboAutor.SelectedValue.ToString)
            DatArticulos._CodTipoArticulo = Convert.ToInt32(cboGenero.SelectedValue.ToString)
            DatArticulos._CodISBN = Convert.ToInt32(cboEditorial.SelectedValue.ToString)
            DatArticulos._Ubicacion = txtUbicacion.Text
            DatArticulos._Cantidad = txtCantidad.Text

            CantidadPrestada = CantidadArticulos()
            CantidadNueva = Convert.ToInt32(txtCantidad.Text)

            If CantidadNueva < CantidadPrestada Then
                MsgBox("Cambie la cantidad de Articulos." + vbCrLf + "El total de Articulos prestados excede a este", MsgBoxStyle.Exclamation, "Mensaje del Sistema")
                Exit Sub
            Else
                NuevoSotck = CantidadNueva - CantidadPrestada
                Call CambiarValorStock(NuevoSotck, CodArticulos)
            End If


            If FuncArticulos.ModificarArticulos(DatArticulos) Then
                Me.Close()
            Else
                MsgBox("El Registro no fue Modificado", MsgBoxStyle.Exclamation, "Mensaje del Sistema")
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Public Function CantidadArticulos() As Integer
        Try
            Dim resultado As DataTable
            DatArticulos._CodArticulos = CodArticulos
            resultado = FuncArticulos.VerificarCantidadLibro(DatArticulos)

            Dim cantidad As Integer

            If resultado.Rows.Count > 0 Then
                cantidad = resultado.Rows.Count
                Return cantidad
            Else
                cantidad = 0
                Return cantidad
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
            Return 0
        End Try
    End Function

    Public Sub CambiarValorStock(ByVal NuevoStock As Integer, ByVal CodArticulos As Integer)
        Try
            dconexion.Conectar()
            Dim sql As String
            sql = "UPDATE stocklibros SET Disponibles = '" + NuevoStock.ToString + "' WHERE CodArticulos = '" + CodArticulos.ToString + "'"
            'MsgBox(sql)
            Dim cmd As New SqlCommand(sql, dconexion.con)

            If cmd.ExecuteNonQuery Then
                'MsgBox("Cambio Modificado Correctamente")
            Else
                MsgBox("NO se pudo modificar los datos debido a la Cantidad puesta")
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            dconexion.Desconectar()
        End Try

    End Sub



    Public Sub CargarAutor()
        Try

            cboAutor.DataSource = FuncArticulosAutor.MostrarAutor

            cboAutor.DisplayMember = "Autor"
            cboAutor.ValueMember = "Codigo"

            If CodArticulosAutor <> 0 Then
                cboAutor.SelectedValue = CodArticulosAutor
            End If
            CodArticulosAutor = 0
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Public Sub CargarGenero()
        Try

            cboGenero.DataSource = FuncTipoArticulo.MostrarGenero

            cboGenero.DisplayMember = "Genero"
            cboGenero.ValueMember = "Codigo"

            If CodTipoArticulo <> 0 Then
                cboGenero.SelectedValue = CodTipoArticulo
            End If
            CodTipoArticulo = 0
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Public Sub CargarEditorial()
        Try

            cboEditorial.DataSource = FuncISBN.MostraEditorial

            cboEditorial.DisplayMember = "Editorial"
            cboEditorial.ValueMember = "Codigo"

            If CodISBN <> 0 Then
                cboEditorial.SelectedValue = CodISBN
            End If
            CodISBN = 0
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
End Class