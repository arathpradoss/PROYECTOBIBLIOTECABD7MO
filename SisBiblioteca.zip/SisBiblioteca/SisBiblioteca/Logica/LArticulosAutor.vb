﻿Public Class LArticulosAutor
    Dim Autor As String
    Dim CodArticulosAutor As Integer
    Public Property _Autor
        Set(value)
            Autor = value
        End Set
        Get
            Return Autor
        End Get
    End Property

    Public Property _CodArticulosAutor
        Set(value)
            CodArticulosAutor = value
        End Set
        Get
            Return CodArticulosAutor
        End Get
    End Property
End Class
