﻿Public Class LAlquilado
    Dim CodAlquilado, CodMiembroNuevo, CodArticulos As Integer

    Dim Fec_Devolucion As Date
    Public Property _CodAlquilado
        Set(value)
            CodAlquilado = value
        End Set
        Get
            Return CodAlquilado
        End Get
    End Property
    Public Property _CodMiembroNuevo
        Set(value)
            CodMiembroNuevo = value
        End Set
        Get
            Return CodMiembroNuevo
        End Get
    End Property

    Public Property _CodArticulos
        Set(value)
            CodArticulos = value
        End Set
        Get
            Return CodArticulos
        End Get
    End Property
    Public Property _FecDevolucion
        Set(value)
            Fec_Devolucion = value
        End Set
        Get
            Return Fec_Devolucion
        End Get
    End Property
End Class
