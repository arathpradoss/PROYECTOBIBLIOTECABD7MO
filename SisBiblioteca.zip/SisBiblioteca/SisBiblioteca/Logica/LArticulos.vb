﻿Public Class LArticulos

    Dim Titulo, Ubicacion As String
    Dim CodArticulos, CodArticulosAutor, CodTipoArticulo, CodISBN, Cantidad As Integer
    Public Property _CodArticulos
        Set(value)
            CodArticulos = value
        End Set
        Get
            Return CodArticulos
        End Get
    End Property
    Public Property _Titulo
        Set(value)
            Titulo = value
        End Set
        Get
            Return Titulo
        End Get
    End Property

    Public Property _Ubicacion
        Set(value)
            Ubicacion = value
        End Set
        Get
            Return Ubicacion
        End Get
    End Property

    Public Property _CodArticulosAutor
        Set(value)
            CodArticulosAutor = value
        End Set
        Get
            Return CodArticulosAutor
        End Get
    End Property

    Public Property _CodTipoArticulo
        Set(value)
            CodTipoArticulo = value
        End Set
        Get
            Return CodTipoArticulo
        End Get
    End Property


    Public Property _CodISBN
        Set(value)
            CodISBN = value
        End Set
        Get
            Return CodISBN
        End Get
    End Property


    Public Property _Cantidad
        Set(value)
            Cantidad = value
        End Set
        Get
            Return Cantidad
        End Get
    End Property
End Class
