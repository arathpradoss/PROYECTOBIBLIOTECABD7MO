﻿Public Class LTipoArticulo
    Dim CodTipoArticulo As Integer
    Dim Tipo As String
    Public Property _Tipo
        Set(value)
            Tipo = value
        End Set
        Get
            Return Tipo
        End Get
    End Property

    Public Property _CodTipoArticulo
        Set(value)
            CodTipoArticulo = value
        End Set
        Get
            Return CodTipoArticulo
        End Get
    End Property
End Class
