﻿Public Class LISBN
    Dim CodISBN As Integer
    Dim NumISBN As String
    Public Property _CodISBN
        Set(value)
            CodISBN = value
        End Set
        Get
            Return CodISBN
        End Get
    End Property

    Public Property _NumISBN
        Set(value)
            NumISBN = value
        End Set
        Get
            Return NumISBN
        End Get
    End Property

End Class
